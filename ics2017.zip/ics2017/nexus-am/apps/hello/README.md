# Hello World

最简单的Hello World程序，使用`_putc`打印一些字符，然后`_halt(0)`终止。

能够运行在任何实现了AM (Turing Machine)的平台上。

## 编译指南

编译前需要设置环境变量AM_HOME为AM项目所在的**绝对路径**。

编译时用`make ARCH=xxx`指定具体的体系结构。