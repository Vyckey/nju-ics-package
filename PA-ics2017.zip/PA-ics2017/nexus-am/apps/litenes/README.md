# LiteNES

Nintendo Entertainment System模拟器。故意做了一些错误的实现以提高性能（所以部分图形显示不正确）。

内置Super Mario Bros游戏ROM (mario.c)。

操作方式:

* T — SELECT
* Y — START
* G — A键
* H — B键
* W/S/A/D — UP/DOWN/LEFT/RIGHT

需要正确的IOE (绘图、定时)。