#ifndef __X86_NEMU_H__
#define __X86_NEMU_H__

#ifndef __ASSEMBLER__
/* The following code will be included if the source file is a "*.c" file. */

#include <arch.h>

#endif

#endif
